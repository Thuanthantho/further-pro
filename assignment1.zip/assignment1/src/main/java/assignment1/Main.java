package assignment1;

import java.io.*;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.nio.file.*;


public class Main 
{
    public static String readProductFile(String productPath) throws IOException {
        return Files.readString(Paths.get(productPath));
    }
    public static String readCartFile(String cartPath) throws IOException {
        return Files.readString(Paths.get(cartPath));
    }

    public static void main( String[] args ) throws IOException {
        String productPath = "../assignment1/src/main/java/assignment1/product.txt";
        String cartPath = "../assignment1/src/main/java/assignment1/cart.txt";

        List<Product> productList = getProductList(productPath); // the list that will only contains products
        List<Coupon> couponList = getCouponList(productPath); // the list that will only contains coupons
        List<ShoppingCart> shoppingCartsList = getShoppingCartLists(cartPath); // the list will contains 0+ numbers of shopping cart for the user
        menu(productList, couponList, shoppingCartsList);
    }

    public static List<Product> getProductList(String productPath) throws IOException{
        List<Product> tempproductList = new ArrayList<>();
        try {
            // read everything inside the file
            String[] currentProduct = readProductFile(productPath).split("\\r?\\n\\r?\\n"); // this will split up between items from the list
                                                                                // (the empty line) (2 times spacing)

            tempproductList = Arrays.stream(currentProduct)
            .filter(line -> !line.isEmpty())
            .filter(line -> line.startsWith("Type: Digital") || line.startsWith("Type: Physical"))
            .map(line -> {
                String[] catandval = line.split("\\r?\\n"); // this will seperate each line of each item as an element inside the list into an array
                String type = catandval[0].split(":")[1].trim(); // taking each line and split them between its category and its value
                String name = catandval[1].split(":")[1].trim();
                String description = catandval[2].split(":")[1].trim();
                int available = Integer.parseInt(catandval[3].split(":")[1].trim());
                double price = Double.parseDouble(catandval[4].split(":")[1].trim().replace("%", "")); // avoid "%" of the coupon
                boolean CanBeGifted = false;
                double weight = 0;
                if (catandval.length > 5) { // these if else to ensure each array will be checked its number of elements
                    CanBeGifted = Boolean.parseBoolean(catandval[5].split(":")[1].trim()); 
                }
                if (catandval.length > 6 && type.equals("Physical") ) {
                    weight = Double.parseDouble(catandval[6].split(":")[1].trim());
                }
                if (type.equals("Physical")) {
                    return new PhysicalProduct(type, name, description, available, price, CanBeGifted, weight);
                } else if (type.equals("Digital")) {
                    return new DigitalProduct(type, name, description, available, price, CanBeGifted);
                } 
                return new Product(type, name, description, available, price, CanBeGifted);
            })
            // .filter(product -> product.getType().equals("Physical") || product.getType().equals("Digital")) 
            // filtering the product // careful of unrecognized product type 
            .collect(Collectors.toList());
            // productList.addAll(tempproductList);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempproductList;
    }


    public static List<Coupon> getCouponList(String productPath) throws IOException{
        List<Coupon> tempcouponList = new ArrayList<>(); // the list that will only contains coupon
        try {
            String[] currentProduct = readProductFile(productPath).split("\\r?\\n\\r?\\n");
            tempcouponList = Arrays.stream(currentProduct)
            .filter(line -> !line.isEmpty())
            .filter(line -> line.startsWith("Type: Coupon"))
            .map(line -> {
                String[] catandval = line.split("\\r?\\n");
                String CouponName = catandval[1].split(":")[1].trim();
                String description = catandval[2].split(":")[1].trim();
                int quantity = Integer.parseInt(catandval[3].split(":")[1].trim());
                String price = catandval[4].split(":")[1].trim();
                if (price.contains("%")) {
                    double discount = Double.parseDouble(catandval[4].split(":")[1].trim().replace("%", ""));
                    boolean isPercentage = true;

                    if (discount >= 0 && discount <= 100 && (discount == Math.floor(discount) || discount == Math.ceil(discount))) {
                        return new Coupon(CouponName, description, quantity, discount, isPercentage); // checking if discount can be an integer or not
                    } else {
                        return null; // return null if the discount value is inappropriate
                    }
                    
                } else {
                    double discount = Double.parseDouble(catandval[4].split(":")[1].trim());
                    boolean isPercentage = false;
                    return new Coupon(CouponName, description, quantity, discount, isPercentage);
                }
            })
            .filter(Objects::nonNull) // filter out any null element in the list
            .collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempcouponList;
    }


    public static List<ShoppingCart> getShoppingCartLists(String cartPath) throws IOException{
        List<ShoppingCart> tempcartList = new ArrayList<>(); // the list that will only contains coupon
        try {
            String[] currentcart = readCartFile(cartPath).split("\\r?\\n\\r?\\n");
            tempcartList = Arrays.stream(currentcart)
            .filter(line -> !line.isEmpty())
            .filter(line -> line.startsWith("Cart ID: "))
            .map(line -> {
                String[] catandval = line.split("\\r?\\n");
                System.out.println(catandval.length);
                int cartID = Integer.parseInt(catandval[0].split(":")[1].trim());
                List<ProductItem> tempItems = new ArrayList<>();
                for (int i = 1; i < catandval.length; i++) {
                    String[] product = catandval[i].split(" - ");
                    if (product.length > 3) {
                        String itemName = product[0].split(":")[1].trim();
                        int amount = Integer.parseInt(product[1].split(":")[1].trim());
                        boolean isGift = true;
                        String message = product[2].split(":")[1].trim();
                        ProductItem newItem = new ProductItem(itemName, amount, message, isGift);
                        tempItems.add(newItem);
                        return new ShoppingCart(cartID, tempItems);
                    } else if (product.length == 2) {
                        String itemName = product[0].split(":")[1].trim();
                        int amount = Integer.parseInt(product[1].split(":")[1].trim());
                        ProductItem newItem = new ProductItem(itemName, amount);
                        tempItems.add(newItem);
                    }
                }
                return new ShoppingCart(cartID, tempItems);  
            })
            .filter(Objects::nonNull) // filter out any null element in the list
            .collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempcartList;
    }

    
    public static void menu(List<Product> productList, List<Coupon> couponList, List<ShoppingCart> shoppingCartsList) throws IOException {

        System.out.println( "---------------------------------------------------------" + "\nType the option what you want: " + 
        "\n1. Show products in store" +
        "\n2. Display current shopping carts" +
        "\n3. Add news products to a new shopping cart" +
        "\n4. Remove products from shopping cart" + 
        "\n5. Update message for gifted product items" + 
        "\n6. Apply coupon" + 
        "\n7. Print purchase receipts" +
        "\n---------------------------------------------------------" );

        Scanner scanner = new Scanner(System.in); 
        try {
            int input = scanner.nextInt();
            switch(input) {
                case 1:

                    System.out.println( "---------------------------------------------------------");

                    System.out.println("All current products in store: ");
                    for (Product item : productList) {
                        System.out.println(item + " - "+ Integer.toString(item.getAvailable()));
                    }

                    System.out.println( "---------------------------------------------------------");
                    menu(productList, couponList, shoppingCartsList);
                break;

                case 2:

                    System.out.println( "---------------------------------------------------------");
                    ProductItem test6 = new ProductItem("test", true);
                    
                    ShoppingCart cart1 = new ShoppingCart(1);
                    cart1.getCurrentCart().add(test6);
                    shoppingCartsList.add(cart1);
                    cart1.displayCart(shoppingCartsList);
                    System.out.println( "---------------------------------------------------------");
                    menu(productList, couponList, shoppingCartsList);

                break;

                case 3:

                    System.out.println( "---------------------------------------------------------");

                    ProductItem test8 = new ProductItem("test", true);
                    cart1 = new ShoppingCart(1);
                    cart1.getCurrentCart().add(test8);
                    shoppingCartsList.add(cart1);
                    cart1.addItem(shoppingCartsList, productList);

                    System.out.println( "---------------------------------------------------------");
                    menu(productList, couponList, shoppingCartsList);

                break;
                
                case 4:

                    System.out.println( "---------------------------------------------------------");

                    ProductItem test7 = new ProductItem("test", true);
                    cart1 = new ShoppingCart(1);
                    cart1.getCurrentCart().add(test7);
                    shoppingCartsList.add(cart1);
                    cart1.removeItem(shoppingCartsList, productList);

                    System.out.println( "---------------------------------------------------------");
                    menu(productList, couponList, shoppingCartsList);

                break;
                

                case 5:

                    System.out.println( "---------------------------------------------------------");

                    ProductItem test = new ProductItem("test", true);
                    test.GiftMessage(test);
                    System.out.println("your message has been set to this item as:"+test.getMessage());

                    // System.out.println( "---------------------------------------------------------");
                    menu(productList, couponList, shoppingCartsList);
                    break;
                case 6:

                    System.out.println( "---------------------------------------------------------");
               
                    Coupon coupon = new Coupon();
                    coupon.applyProductCoupon(couponList, shoppingCartsList);

                    System.out.println( "---------------------------------------------------------");
                    menu(productList, couponList, shoppingCartsList);
                    break;
                case 7:

                    System.out.println( "---------------------------------------------------------");


                    System.out.println( "---------------------------------------------------------");
                    menu(productList, couponList, shoppingCartsList);
                break;

                default:
                System.out.println("===============================" + "\n====Invalid Input, re-enter====" + "\n=============================== \n");
                
            }
            scanner.close();
        } catch (InputMismatchException e) {
            System.out.println("===============================" + "\n====Invalid Input, re-enter====" + "\n=============================== \n");
            menu(productList, couponList, shoppingCartsList);
        }
    }
    
}


