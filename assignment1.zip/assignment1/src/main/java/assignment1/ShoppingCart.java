package assignment1;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ShoppingCart { 
    private int cartID;
    private List<ProductItem> currentCart;
    private boolean appliedCoupon = false;

    public ShoppingCart(int cartID, List<ProductItem> currentCart, boolean appliedCoupon){
        this.cartID = cartID;
        this.currentCart = currentCart;
        this.appliedCoupon = appliedCoupon;
    }
    public ShoppingCart(int cartID, List<ProductItem> currentCart){
        this.cartID = cartID;
        this.currentCart = currentCart;
    }
    public ShoppingCart(int cartID) {
        this.cartID = cartID;
        this.currentCart = new ArrayList<ProductItem>();
    }

    public int getCartID() {
        return cartID;
    }
    public void setCartID(int cartID) {
        this.cartID = cartID;
    }
    public void setCurrentCart(List<ProductItem> currentCart) {
        this.currentCart = currentCart;
    }
    public List<ProductItem> getCurrentCart() {
        return currentCart;
    }
    public boolean isAppliedCoupon() {
        return appliedCoupon;
    }
    public void setAppliedCoupon(boolean appliedCoupon) {
        this.appliedCoupon = appliedCoupon;
    }

	public boolean addItem(List<ShoppingCart> shoppingCartsList, List<Product> productList) throws IOException {
        try {
            if (shoppingCartsList.isEmpty()) { // checking if the user has any shopping cart yet -> allow to create new shopping cart
                System.out.println("You currently don't have any shopping cart!"); // a reader for the pre-made shopping carts will be made later so for now this scenario would still be possible
                System.out.println("Do you want to create a new shopping cart? (Yes/No)");
                Scanner scanner = new Scanner(System.in);
                String newCart = scanner.nextLine();
                if (newCart.equalsIgnoreCase("yes")) {
                    newShoppingCart(shoppingCartsList);
                    return false;
                } else {
                    return false;
                }

            } else { // if there are at least 1 cart existed
                System.out.println("Your Shopping Cart(s): ");
                for (ShoppingCart currentShoppingCart : shoppingCartsList) { // print out all available cart(s)
                    System.out.println(currentShoppingCart);            
                }

                System.out.println("Which cart would you like to access? (Please insert by the Cart number)");
                Scanner scanner = new Scanner(System.in);
                int currentcartID = scanner.nextInt();

                boolean validCartID = shoppingCartsList.stream() // using stream to check if input is valid 
                .map(ShoppingCart::getCartID) // for each shopping cart object
                .anyMatch(cartID -> cartID == currentcartID); // finding match

                if (validCartID) { // after the correct cardID has been chosen
                    List<ProductItem> currentCart = shoppingCartsList.get(currentcartID - 1).getCurrentCart(); // retrieve the productItem List
                    
                    try {Thread.sleep(1000);} catch (InterruptedException e) {}
                    for (ProductItem currentItems : currentCart) { 
                        System.out.println(currentItems); // print out the cart
                    }
                    
                    IntStream.range(0, productList.size())
                    .forEach(i -> System.out.println((i + 1) + ". " +  productList.get(i)));

                    System.out.println("Which item do you want to add? (Please insert by the product number (ie. \"1\"))");
                    Scanner scanner1 = new Scanner(System.in);
                    int choose = scanner1.nextInt();
                    boolean validProduct;
                    if (choose > 0 && choose <= productList.size()) {
                        validProduct = true;
                    } else {
                        validProduct = false;
                    }

                    
                    if (validProduct) { 
                        Product currentProduct = productList.get(choose - 1);
    
                        System.out.println("Currently the item \"" + currentProduct.getName() +"\" has " + currentProduct.getAvailable() + " stocks in our shop.");
                        System.out.println("How many of this item would you want to purchase");
                        Scanner scanner2 = new Scanner(System.in);
                        int buying = scanner2.nextInt();

                        if (currentProduct.getAvailable() >= buying) { // customer buys appropriate amount of items
                            ProductItem addProductItem = new ProductItem(currentProduct.getName()); // this product item current does not hold anything (attribute Gift or CanBeGifted = false)
                            addProductItem.setAmount(buying); // set amount for ProductItem

                            boolean checking = productList.stream() // because the current addProductItem attribute does not match the Product attribute (CanBeGifted)
                            .filter(product -> product.getName().equalsIgnoreCase(currentProduct.getName())) // so this stream purpose is to retrieve CanBeGifted original attribute
                            .map(Product::isCanBeGifted)
                            .findFirst()
                            .orElse(false);
                            
                            addProductItem.setCanBeGifted(checking); // set the original Product attribute

                            if (addProductItem.isCanBeGifted() == true) { // item can be gifted
                                System.out.println("Do you want to send this(these) as gift(s)? (Yes/No)");
                                Scanner scanner3 = new Scanner(System.in);
                                String giftornot = scanner3.nextLine().trim();

                                if (giftornot.equalsIgnoreCase("Yes")) {
                                    addProductItem.setGift(true); 

                                    System.out.println("Would you like to attach a message? (Yes/No)");
                                    Scanner scanner4 = new Scanner(System.in);
                                    String attachMessage = scanner4.nextLine().trim();

                                    if (attachMessage.equalsIgnoreCase("Yes")) { // customer wants to attach a message -> write message -> update
                                        addProductItem.GiftMessage(addProductItem);

                                        for (Product updatingProduct : productList) { // updating stock of the Product inside the productList
                                            if (updatingProduct.getName().equalsIgnoreCase(currentProduct.getName())) {
                                                updatingProduct.setAvailable(updatingProduct.getAvailable() - buying);
                                                break;
                                            }
                                        }
                                        currentCart.add(addProductItem); // adding the new item into the cart
                                        return true;
                                        
                                    } else if (attachMessage.equalsIgnoreCase("No")) { // customer does not want to attach a message -> update
                                        
                                        for (Product updatingProduct : productList) { // updating stock of the Product inside the productList
                                            if (updatingProduct.getName().equalsIgnoreCase(currentProduct.getName())) {
                                                updatingProduct.setAvailable(updatingProduct.getAvailable() - buying);
                                                break;
                                            }
                                        }
                                        currentCart.add(addProductItem); // adding the new item into the cart
                                        return true;

                                    } else {
                                        System.out.println("Invalid input!!");
                                        return false;
                                    }

                                } else if (giftornot.equalsIgnoreCase("No")) { // customer doesn't want to gift -> add item into the cart
                                    for (Product updatingProduct : productList) { // updating stock of the Product inside the productList
                                        if (updatingProduct.getName().equalsIgnoreCase(currentProduct.getName())) {
                                            updatingProduct.setAvailable(updatingProduct.getAvailable() - buying);
                                            break;
                                        }
                                    }
                                    currentCart.add(addProductItem); // adding the new item into the cart
                                    return true;

                                } else {
                                    System.out.println("Invalid input!!");
                                    return false;
                                }
    
                            } else { // item can not be gifted
                                for (Product updatingProduct : productList) { // updating stock of the Product inside the productList
                                    if (updatingProduct.getName().equalsIgnoreCase(currentProduct.getName())) {
                                        updatingProduct.setAvailable(updatingProduct.getAvailable() - buying);
                                        break;
                                    }
                                }
                                currentCart.add(addProductItem); // adding the new item into the cart
                                return true;
                            }

                        } else { // customer buys "IN"appropriate amount of items
                            System.out.println("Invalid amount!!");
                            return false;
                        }
                    } else {
                        System.out.println("Invalid Product Name!");
                        return false;
                    }
                } else {
                    System.out.println("Invalid Cart number!\nPlease try again!!");
                    return false;
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Incorrect input!");
            return false;
        } catch(NoSuchElementException e) { // when users didn't input anything
            System.out.println("No input found!");
            return false;
        }


    }

    public boolean removeItem(List<ShoppingCart> shoppingCartsList, List<Product> productList) throws IOException {
        try {
            if (shoppingCartsList.isEmpty()) { // checking if the user has any shopping cart yet -> allow to create new shopping cart
                System.out.println("You currently don't have any shopping cart!"); // a reader for the pre-made shopping carts will be made later so for now this scenario would still be possible
                System.out.println("Do you want to create a new shopping cart? (Yes/No)");
                Scanner scanner = new Scanner(System.in);
                String newCart = scanner.nextLine();
                if (newCart.equalsIgnoreCase("yes")) {
                    newShoppingCart(shoppingCartsList);
                    return false;
                } else {
                    return false;
                }
            } else { // if there are at least 1 cart existed
                System.out.println("Your Shopping Cart(s): ");
                for (ShoppingCart currentShoppingCart : shoppingCartsList) { // print out all available cart(s)
                    System.out.println(currentShoppingCart);            
                }
                System.out.println("Which cart would you like to access? (Please insert by the Cart number)");
                Scanner scanner = new Scanner(System.in);
                int currentcartID = scanner.nextInt();

                boolean validCartID = shoppingCartsList.stream() // using stream to check if input is valid 
                .map(ShoppingCart::getCartID) // for each shopping cart object
                .anyMatch(cartID -> cartID == currentcartID); // finding match

                if (validCartID) { // after the correct cardID has been chosen
                    List<ProductItem> currentCart = shoppingCartsList.get(currentcartID - 1).getCurrentCart(); // retrieve the productItem List
                    for (ProductItem currentItems : currentCart) { 
                        System.out.println(currentItems); // print out the cart
                    }
                    System.out.println("Which item do you want to remove? (Please insert by the product name)");

                    Scanner scanner1 = new Scanner(System.in);
                    String itemtoRemove = scanner1.nextLine().trim(); // retrieving user's product name

                    Predicate<ProductItem> itemFilter = item -> item.getName().equalsIgnoreCase(itemtoRemove); // kinda like a filter placeholder
                    List<ProductItem> targetItems = currentCart.stream() // this will return a list that has the items name match with the user's input
                    .filter(itemFilter)
                    .collect(Collectors.toList());

                    System.out.println("These are Product Items are matches with your input: "); 
                    IntStream.range(0, targetItems.size())
                    .forEach(i -> System.out.println((i + 1) + ". " +  targetItems.get(i)));

                    System.out.println("Which product do you want to delete specifically (insert their number i.e \"1\") (or you can delete all of them by entering \"all\")?");

                    Scanner scanner2 = new Scanner(System.in);
                    String deleting = scanner2.nextLine().trim();
                    if (deleting.equalsIgnoreCase("all")) { // delete all items based on the criteria
                        for (ProductItem deleteItem : targetItems) { // deleting the items from the cart 1 by 1
                            currentCart.remove(deleteItem);

                            for (Product updatingProduct : productList) { // updating stock of the Product inside the productList
                                if (updatingProduct.getName().equalsIgnoreCase(itemtoRemove)) {
                                    updatingProduct.setAvailable(updatingProduct.getAvailable() + deleteItem.getAmount());
                                    break;
                                }
                            }

                        }
                        
                        return true;

                    } else if (Integer.parseInt(deleting) > 0 && Integer.parseInt(deleting) <= targetItems.size()) { // delete some items of the list
                        
                        for (Product updatingProduct : productList) { // updating stock of the Product inside the productList
                            if (updatingProduct.getName().equalsIgnoreCase(itemtoRemove)) {
                                updatingProduct.setAvailable(updatingProduct.getAvailable() + targetItems.get(Integer.parseInt(deleting) - 1).getAmount());
                                break;
                            }
                        }

                        currentCart.remove(targetItems.get(Integer.parseInt(deleting) - 1)); // deleting the item
                        System.out.println(currentCart);
                        return true;
                    
                    } else {
                        System.out.println("Invalid input!!");
                        return false;
                    }
                } else {
                    System.out.println("Invalid input!!");
                    return false;
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input!!");
            return false;
        } catch (NoSuchElementException e) {
            System.out.println("No input found!");
            return false;
        }
    }

    public boolean displayCart(List<ShoppingCart> shoppingCartsList) throws IOException {
        try{
            if (shoppingCartsList.isEmpty()) { // checking if the user has any shopping cart yet -> allow to create new shopping cart
                System.out.println("You currently don't have any shopping cart!"); // a reader for the pre-made shopping carts will be made later so for now this scenario would still be possible
                System.out.println("Do you want to create a new shopping cart? (Yes/No)");
                Scanner scanner = new Scanner(System.in);
                String newCart = scanner.nextLine();
                if (newCart.equalsIgnoreCase("yes")) {
                    newShoppingCart(shoppingCartsList);
                    return false;
                } else {
                    return false;
                }
            } else { // if there are at least 1 cart existed
                System.out.println("Your Shopping Cart(s): ");
                for (ShoppingCart currentShoppingCart : shoppingCartsList) { // print out all available cart(s)
                    System.out.println(currentShoppingCart);            
                }

                System.out.println("Which cart would you like to access? (Please insert by the Cart number)");
                Scanner scanner = new Scanner(System.in);
                int currentcartID = scanner.nextInt();

                boolean validCartID = shoppingCartsList.stream() // using stream to check if input is valid 
                .map(ShoppingCart::getCartID) // for each shopping cart object
                .anyMatch(cartID -> cartID == currentcartID); // finding match

                if (validCartID) { // after the correct cardID has been chosen
                    List<ProductItem> currentCart = shoppingCartsList.get(currentcartID - 1).getCurrentCart(); // retrieve the productItem List
                    for (ProductItem currentItems : currentCart) { 
                        System.out.println(currentItems); // print out the cart
                    } 
                } else {
                        System.out.println("Invalid Cart number!\nPlease try again!!");
                        displayCart(shoppingCartsList);     
                }
            }
        }
        catch (InputMismatchException e) {
            System.out.println("Incorrect input!");
            return false;
        } catch(NoSuchElementException e) { // when users didn't input anything
            System.out.println("No input found!");
            return false;
        }
        return false;
    }

    public boolean newShoppingCart(List<ShoppingCart> shoppingCartsList) throws IOException {
        int newCartID = 0;
        for (ShoppingCart shoppingCart : shoppingCartsList) {
            int cartID = shoppingCart.getCartID();
            if (cartID > newCartID) {
                newCartID = cartID;
            }
        }
        newCartID = newCartID + 1;

        ShoppingCart newShoppingCart = new ShoppingCart(newCartID);
        shoppingCartsList.add(newShoppingCart);
        return true;
    }

    public double getTotalCost(List<ShoppingCart> shoppingCartsList, List<Product> productList) {
        double total = 0.0;

        for (ShoppingCart shoppingCart : shoppingCartsList) {
            for (ProductItem item : shoppingCart.getCurrentCart()) {
                total += item.getPrice() * item.getAmount(); // adding the money of item price + quantity
            }
        }
        total += getShippingFee(shoppingCartsList, productList) + getTaxPayment(shoppingCartsList, productList);
        return total;
    }

    public double getTaxPayment(List<ShoppingCart> shoppingCartsList, List<Product> productList) {
        double tax = 0.0;
        TaxType luxuryTax = TaxType.LUXURY_TAX;
        TaxType noTax = TaxType.TAX_FREE;
        TaxType normalTax = TaxType.NORMAL_TAX;
        double taxRate = normalTax.getRate();

        for (ShoppingCart shoppingCart : shoppingCartsList) {
            for (ProductItem item : shoppingCart.getCurrentCart()) {
                for (Product product : productList) {
                    if (item.getName().equals(product.getName())) {
                        tax += product.getPrice() * item.getAmount() * taxRate;
                    }
                }
            }
        }
        return tax;
    }

    public double getShippingFee(List<ShoppingCart> shoppingCartsList, List<Product> productList) {
        double weight = 0.0;
        double shippingfee = 0.0;
        for (ShoppingCart shoppingCart : shoppingCartsList) {
            for (ProductItem item : shoppingCart.getCurrentCart()) {
                if (item.getProduct() instanceof Product) {
                    weight += ((PhysicalProduct)item.getProduct()).getWeight() * item.getAmount();
                }
                shippingfee += weight * 0.1; // adding the money of the physical products' weight
            }
        }
        return shippingfee;
    }

    public void printReceipt(List<ShoppingCart> shoppingCartsList, List<Product> productList) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        TaxType normalTax = TaxType.NORMAL_TAX;
        double taxRate = normalTax.getRate();

        System.out.println("---------------------PURCHASE RECEIPT---------------------");
        System.out.printf("| %-30s | %10s | %10s | %10s | %10s |\n", "ITEM", "PRICE", "QUANTITY", "TAX", "TOTAL");
        for (ShoppingCart shoppingCart : shoppingCartsList) {
            for (ProductItem item : shoppingCart.getCurrentCart()) {
                double tax = 0.0;
                for (Product product : productList) {
                    if (item.getName().equals(product.getName())) {
                        tax = product.getPrice() * item.getAmount() * taxRate;
                        break;
                    }
                }
                double total = item.getProduct().getPrice() * item.getAmount() + tax;
            System.out.printf("| %-30s | %,10.2f | %10d | %,10.2f | %,10.2f |\n",
                    item.getProduct().getName(), item.getProduct().getPrice(),
                    item.getAmount(), tax, total);
        }
        }
        double weight = 0.0;
        for (ShoppingCart shoppingCart : shoppingCartsList) {
            for (ProductItem item : shoppingCart.getCurrentCart()) {
                if (item.getProduct() instanceof Product) {
                    weight += ((PhysicalProduct)item.getProduct()).getWeight() * item.getAmount();
                }
            }
        }
        System.out.printf("| %-30s | %10s |\n", "SHIPPING FEE", String.format("%,10.2f", getShippingFee(shoppingCartsList, productList)));
        System.out.printf("| %-30s | %10s |\n", "", "");
        double totalCost = getTotalCost(shoppingCartsList, productList);
        System.out.printf("| %-30s | %10s |\n", "TOTAL COST", String.format("%,10.2f", totalCost));
        System.out.printf("| %-30s | %10s |\n", "", "");
        System.out.printf("| %-30s | %-30s |\n", "PURCHASE DATE", dateFormat.format(new Date()));
        System.out.println("-----------------------------------------------------------");
    }


    @Override
    public String toString() {
        return "\nCart No: " + this.getCartID() + "\nCurrently has: " + this.currentCart;
    }
}
