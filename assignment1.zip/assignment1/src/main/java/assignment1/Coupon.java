package assignment1;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Coupon {
    private String CouponName;
    private String description;
    private int quantity;
    private double discount;
    private boolean isPercentage;
    

    public Coupon(String CouponName, String description, int quantity, double discount, boolean isPercentage){
        this.CouponName = CouponName;
        this.description = description;
        this.quantity = quantity;
        this.discount = discount;
        this.isPercentage = isPercentage;
    }

    public Coupon() {
        this.CouponName = "";
        this.description = "";
        this.quantity = 0;
        this.discount = 0;
        this.isPercentage = false;
    }

    public String getCouponName() {
        return CouponName;
    }
    public String getDescription() {
        return description;
    }
    public int getQuantity() {
        return quantity;
    }
    public double getDiscount() {
        return discount;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean applyProductCoupon(List<Coupon> couponList, List<ShoppingCart> shoppingCartsList) {

        List<Coupon> productCoupons = couponList.stream()
        .filter(coupon -> !coupon.getCouponName().contains("Shipping"))
        .collect(Collectors.toList()); // return a list with Coupon specifically for product price discount

        try {Thread.sleep(1500);} catch (InterruptedException e) {}
        System.out.println("\nPlease keep in mind that (singular) item that has a price < 30$ can only be used with 30% discount and below or below flat 20$ discount"
                            + "\nItems that are 30$ or above will be able to use coupon that are above 30+ % discount or flat 20+ $ discount" 
                            + "\nThis also applies for Shopping Cart total price which 100$ is the threshhold");

        try {Thread.sleep(1500);} catch (InterruptedException e) {}

        try {
            System.out.println("Your Shopping Cart(s): ");
            for (ShoppingCart currentShoppingCart : shoppingCartsList) { // print out all available cart(s)
                System.out.println(currentShoppingCart);  
            }    
            System.out.println("Which cart would you like to access? (Please insert by the Cart number)");
            Scanner scanner = new Scanner(System.in);
            int currentcartID = scanner.nextInt();

            boolean validCartID = shoppingCartsList.stream() // using stream to check if input is valid 
            .map(ShoppingCart::getCartID) // for each shopping cart object
            .anyMatch(cartID -> cartID == currentcartID); // finding match

            if (validCartID) { // after the correct cardID has been chosen
                List<ProductItem> currentCart = shoppingCartsList.get(currentcartID - 1).getCurrentCart(); // retrieve the productItem List

                System.out.println("Which item do you want to apply the coupon on? (Please insert by the product number (ie. \"1\"))");
                
                IntStream.range(0, currentCart.size())
                .forEach(i -> System.out.println((i + 1) + ". " +  currentCart.get(i))); // print out product items existed in the cart

                Scanner scanner1 = new Scanner(System.in);
                int choose = scanner1.nextInt();
                boolean validProductItem;
                if (choose > 0 && choose <= currentCart.size()) { // taking boolean value to validate 
                    validProductItem = true;
                } else {
                    validProductItem = false;
                }

                if (validProductItem) { 
                    ProductItem currentProductItem = currentCart.get(choose - 1); // taking instance of the object

                    if (currentProductItem.isDiscount() == false) { // check if this product contains coupon
                        if (currentProductItem.getPrice() < 30) { // items have price < 30$
                            List<Coupon> validCoupons = productCoupons.stream() // gather valid coupons
                            .filter(coupon -> coupon.getDiscount() < 30 && coupon.isPercentage == true || coupon.getDiscount() < 20 && coupon.isPercentage == false)
                            .collect(Collectors.toList());
    
                            System.out.println("These are the coupons you can apply: ");
    
                            IntStream.range(0, validCoupons.size())
                            .forEach(i -> System.out.println((i + 1) + ". " + validCoupons.get(i))); // printing all valid coupons for that product
    
                            System.out.println("Which coupon would you like to apply? (Pick by its number)");
                            Scanner scanner2 = new Scanner(System.in);
                            int choose2 = scanner.nextInt();
                            if (choose2 > 0 && choose2 <= validCoupons.size()) { // apply valid coupon
                                System.out.println("You are choosing: " + validCoupons.get(choose2 - 1) + "\n");
                                
                                for (Coupon updatingCoupon : couponList) { // updating stock of the Product inside the productList
                                    if (updatingCoupon.getCouponName().equalsIgnoreCase(validCoupons.get(choose2 - 1).getCouponName())) {
                                        updatingCoupon.setQuantity(updatingCoupon.getQuantity() - currentProductItem.getAmount()); // current coupon quantity - number of items
                                        
                                        if (updatingCoupon.isPercentage == true) {
                                            currentProductItem.setPrice(currentProductItem.getPrice() * discount / 100);
                                            currentProductItem.setDiscount(true);
                                        } else {
                                            currentProductItem.setPrice(currentProductItem.getPrice() - discount);
                                            currentProductItem.setDiscount(true);
                                        }
                                        break;
                                    }
                                }
                                return true;                    
                            } else {
                                System.out.println("Invalid input!!");
                                return false;
                            }
    
                        } else { // items have price >= 30$
                            System.out.println("These are the coupons you can apply: ");
    
                            IntStream.range(0, productCoupons.size())
                            .forEach(i -> System.out.println((i + 1) + ". " + productCoupons.get(i))); // printing all valid coupons for that product
    
                            System.out.println("Which coupon would you like to apply? (Pick by its number)");
                            Scanner scanner2 = new Scanner(System.in);
                            int choose2 = scanner.nextInt();
                            if (choose2 > 0 && choose2 <= productCoupons.size()) { // apply valid coupon
                                System.out.println("You are choosing: " + productCoupons.get(choose2 - 1) + "\n");
                                
                                for (Coupon updatingCoupon : couponList) { // updating stock of the Product inside the productList
                                    if (updatingCoupon.getCouponName().equalsIgnoreCase(productCoupons.get(choose2 - 1).getCouponName())) {
                                        updatingCoupon.setQuantity(updatingCoupon.getQuantity() - currentProductItem.getAmount()); // current coupon quantity - number of items
                                        
                                        if (updatingCoupon.isPercentage == true) {
                                            currentProductItem.setPrice(currentProductItem.getPrice() * discount / 100);
                                            currentProductItem.setDiscount(true);
                                        } else {
                                            currentProductItem.setPrice(currentProductItem.getPrice() - discount);
                                            currentProductItem.setDiscount(true);
                                        }
                                        break;
                                    }
                                }
                                return true;
                            } else {
                                System.out.println("Invalid input!!");
                                return false;
                            }
                        }
                    } else {
                        System.out.println("This product has already been attached with a coupon");
                        return false;
                    }
                    
                }
            } 
        } catch (InputMismatchException e) {
            System.out.println("Invalid input!!");
            // scanner.close();
            applyProductCoupon(couponList, shoppingCartsList);
        }
        return false;
    }

    public boolean applyShippingCoupon(List<Coupon> couponList, List<ShoppingCart> shoppingCartsList) {
        List<Coupon> shippingCoupons = couponList.stream()
        .filter(coupon -> coupon.getCouponName().contains("Shipping"))
        .collect(Collectors.toList()); // return a list with Coupon specifically for shipping fee discount

        System.out.println("These are currently coupons you can apply: ");
        IntStream.range(0, shippingCoupons.size())
        .forEach(i -> System.out.println((i + 1) + ". " + shippingCoupons.get(i)));

        System.out.println("Which coupon would you like to apply? (Pick by its number)");
        Scanner scanner = new Scanner(System.in);
        try {
            int choose = scanner.nextInt();
            if (choose > 0 && choose <= shippingCoupons.size()) {
                


            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input!!");
            scanner.close();
            applyShippingCoupon(couponList, shoppingCartsList);
        }
        if (applyProductCoupon(couponList, shoppingCartsList) == false) {

        }
        return false;
    }





    public boolean changeProductCoupon(List<Coupon> couponList, List<ShoppingCart> shoppingCartsList) {
        return false;
    }

    public boolean changeShippingCoupon(List<Coupon> couponList, List<ShoppingCart> shoppingCartsList) {
        return false;
    }

    @Override
    public String toString() {
        return this.getCouponName() + " - Quantity: " + this.getQuantity();
    }
    
}
