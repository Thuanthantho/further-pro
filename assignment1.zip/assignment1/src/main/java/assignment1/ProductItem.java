package assignment1;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class ProductItem extends Product{
    private int amount;
    private String message;
    private boolean Gift = false;
    private boolean isDiscount = false;


    public ProductItem(String type, String name, String description, int available, 
    double price, boolean CanBeGifted , int amount, String message, boolean Gift, boolean isDiscount) {
        super(type, name, description, available, price, CanBeGifted);
        this.amount = amount;
        this.message = message;
        this.Gift = Gift;
        this.isDiscount = isDiscount;
    }

    public ProductItem(String name, int amount, String message, boolean Gift, boolean isDiscount) {
        super(name);
        this.amount = amount;
        this.message = message;
        this.Gift = Gift;
        this.isDiscount = isDiscount;
    }
    public ProductItem(String name, int amount, String message, boolean Gift) {
        super(name);
        this.amount = amount;
        this.message = message;
        this.Gift = Gift;
    }

    public ProductItem(String name) {
        super(name);
    }

    public ProductItem(String name, boolean Gift) {
        super(name);
        this.Gift = Gift;
    }
    public ProductItem(String name, int amount) {
        super(name);
        this.amount = amount;
    }

    public int getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public void setGift(boolean Gift) {
        this.Gift = Gift;
    }
    public boolean isGift() {
        return Gift;
    }
    public void setDiscount(boolean isDiscount) {
        this.isDiscount = isDiscount;
    }
    public boolean isDiscount() {
        return isDiscount;
    }
    public Product getProduct() {
        return null;
    }
    

    public void GiftMessage(ProductItem currentProductItem) throws IOException{
        // if (!currentProductItem.isCanBeGifted()) {
        //     System.out.println("This item can not be gifted!");
        //     return;
        // }
            
        if (currentProductItem.getMessage() == null) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("What message would you like to send?");
            String message = scanner.nextLine();
            System.out.println("Your current message is: " + message);
            System.out.println("Are you sure? (Yes/No)");
            Scanner scanner2 = new Scanner(System.in);
            String confirmation = scanner2.nextLine();
            if (confirmation.trim().equalsIgnoreCase("Yes")) {
                currentProductItem.setMessage(message);
            } else if (confirmation.trim().equalsIgnoreCase("No")) {
                GiftMessage(currentProductItem);
            } else {
                System.out.println("Invalid input!!");
                GiftMessage(currentProductItem);
            }
        } else {
            System.out.println("This item is currently attached with a message: " + currentProductItem.getMessage());
            System.out.println("Would you like to change or remove the message (enter \"no\" if you don't want to change)?");
            Scanner scanner = new Scanner(System.in);
            String change = scanner.nextLine();
            if (change.trim().equalsIgnoreCase("change")) {
                System.out.println("What is your new message?");
                Scanner newmessage = new Scanner(System.in);
                newmessage.nextLine();
                String message = "" + newmessage;
                currentProductItem.setMessage(message);
                GiftMessage(currentProductItem);
            } else if (change.trim().equalsIgnoreCase("remove")) {
                String message = null;
                currentProductItem.setMessage(message);
                GiftMessage(currentProductItem);
            } else if (change.trim().equalsIgnoreCase("no")) {
                return;
            }
        }
    }
    
    public String viewMessage(List<ShoppingCart> shoppingCartsList) throws IOException{
        return "";
    }



    @Override
    public String toString() {
        if (message == null) {
            return this.getName() + " - " + this.getAmount();
        } else {
            return this.getName() + " - " + this.getAmount() + " - Gift";
        }
    }
}