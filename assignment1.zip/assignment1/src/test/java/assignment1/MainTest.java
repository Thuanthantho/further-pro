package assignment1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.nio.file.*;
import org.junit.jupiter.api.*;

/**
 * Unit test for simple App.
 */
public class MainTest 
{   String filePath = "../assignment1/src/main/java/assignment1/product.txt";;

     // the list that will only contains coupons
    List<ShoppingCart> shoppingCartsList = new ArrayList<>();


    public static String readFile(String filePath) throws IOException {
        return Files.readString(Paths.get(filePath));
    }
    public static List<Coupon> getCouponList(String filePath) throws IOException{
        List<Coupon> tempcouponList = new ArrayList<>(); // the list that will only contains coupon
        try {
            String[] currentProduct = readFile(filePath).split("\\r?\\n\\r?\\n");
            tempcouponList = Arrays.stream(currentProduct)
            .filter(line -> !line.isEmpty())
            .filter(line -> line.startsWith("Type: Coupon"))
            .map(line -> {
                String[] catandval = line.split("\\r?\\n");
                String CouponName = catandval[1].split(":")[1].trim();
                String description = catandval[2].split(":")[1].trim();
                int quantity = Integer.parseInt(catandval[3].split(":")[1].trim());
                String price = catandval[4].split(":")[1].trim();
                if (price.contains("%")) {
                    
                    double discount = Double.parseDouble(catandval[4].split(":")[1].trim().replace("%", ""));
                    boolean isPercentage = true;
                    return new Coupon(CouponName, description, quantity, discount, isPercentage);
             
                      
                    
                } else {
                    double discount = Double.parseDouble(catandval[4].split(":")[1].trim());
                    boolean isPercentage = false;
                    return new Coupon(CouponName, description, quantity, discount, isPercentage);
                }
            })
            .collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempcouponList;
    }


    public static List<Product> getProductList(String filePath) throws IOException{
        List<Product> tempproductList = new ArrayList<>();
        try {
            // read everything inside the file
            String[] currentProduct = readFile(filePath).split("\\r?\\n\\r?\\n"); // this will split up between items from the list
                                                                                // (the empty line) (2 times spacing)

            tempproductList = Arrays.stream(currentProduct)
            .filter(line -> !line.isEmpty())
            .filter(line -> line.startsWith("Type: Digital") || line.startsWith("Type: Physical"))
            .map(line -> {
                String[] catandval = line.split("\\r?\\n"); // this will seperate each line of each item as an element inside the list into an array
                String type = catandval[0].split(":")[1].trim(); // taking each line and split them between its category and its value
                String name = catandval[1].split(":")[1].trim();
                String description = catandval[2].split(":")[1].trim();
                int available = Integer.parseInt(catandval[3].split(":")[1].trim());
                double price = Double.parseDouble(catandval[4].split(":")[1].trim().replace("%", "")); // avoid "%" of the coupon
                boolean CanBeGifted = false;
                double weight = 0;
                if (catandval.length > 5) { // these if else to ensure each array will be checked its number of elements
                    CanBeGifted = Boolean.parseBoolean(catandval[5].split(":")[1].trim()); 
                }
                if (catandval.length > 6 && type.equals("Physical") ) {
                    weight = Double.parseDouble(catandval[6].split(":")[1].trim());
                }
                if (type.equals("Physical")) {
                    return new PhysicalProduct(type, name, description, available, price, CanBeGifted, weight);
                } else if (type.equals("Digital")) {
                    return new DigitalProduct(type, name, description, available, price, CanBeGifted);
                } 
                return new Product(type, name, description, available, price, CanBeGifted);
            })
            // .filter(product -> product.getType().equals("Physical") || product.getType().equals("Digital")) 
            // filtering the product // careful of unrecognized product type 
            .collect(Collectors.toList());
            // productList.addAll(tempproductList);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempproductList;
    }
    
    

@Test
 public void checkGetProductList() throws IOException {
    
    List<Product> productList = getProductList(filePath);
        assertNotNull(productList, "the store had no products in it");
      }

      @Test
      public void checkGetCouponListList() throws IOException{
    List<Coupon> couponList = getCouponList(filePath);
        assertNotNull(couponList, "The shop does not have any coupons");
      }

    //   @Test
    //   public void checkMessage() throws IOException{
    //     ProductItem test = new ProductItem("test", true);
    //     test.GiftMessage(test);
    //     assertNotNull(test.getMessage(), "The product doesn't have message");
    //   }
       
}

